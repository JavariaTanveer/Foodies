<?php

include './connect.php';

session_start();

$dboy_id= $_SESSION['dboy_id'];
if(!isset($dboy_id)){
   header('location:dboy_login.php');
};

if(isset($_POST['submit'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);
   $cpass = sha1($_POST['cpass']);
   $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

   $select_dboy = $conn->prepare("SELECT * FROM `dboy` WHERE name = ?");
   $select_dboy->execute([$name]);
   
   if($select_dboy->rowCount() > 0){
      $message[] = 'username already exists!';
   }else{
      if($pass != $cpass){
         $message[] = 'confirm passowrd not matched!';
      }else{
         $insert_dboy = $conn->prepare("INSERT INTO `dboy`(name, password) VALUES(?,?)");
         $insert_dboy->execute([$name, $cpass]);
         $message[] = 'new dboy registered!';
      }
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="./css/admin_style.css">

</head>
<body>

<?php include './dboy_header.php' ?>

<!-- register admin section starts  -->
<style>
h3 {
  text-align: center;
  margin-bottom: 20px;
}


label {
  font-weight: bold;
  display: block;
  margin-bottom: 5px;
  font-size: 15px;
}

.required::after {
  content: '*';
  color: red;
  margin-left: 5px;
}
</style>
<section class="form-container">

   <!-- <form action="" method="POST">
      <h3>register new</h3>
      <input type="text" name="name" maxlength="20" required placeholder="enter your username" class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="pass" maxlength="20" required placeholder="enter your password" class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="cpass" maxlength="20" required placeholder="confirm your password" class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="submit" value="register now" name="submit" class="btn">
   </form> -->

   <div class="container">
    <form action="" method="POST">
      <h3>Register New</h3>
      <label for="name" align="Left">Enter Username<span class="required"></span></label>
      <input type="text" name="name" maxlength="20" required placeholder="Enter your username" class="box" oninput="this.value = this.value.replace(/\s/g, '')">

      <label for="pass" align="Left">Enter Password<span class="required"></span></label>
      <input type="password" name="pass" maxlength="20" required placeholder="Enter your password" class="box" oninput="this.value = this.value.replace(/\s/g, '')">

      <label for="cpass" align="Left">Confirm Password<span class="required"></span></label>
      <input type="password" name="cpass" maxlength="20" required placeholder="Confirm your password" class="box" oninput="this.value = this.value.replace(/\s/g, '')">

      <input type="submit" value="Register Now" name="submit" class="btn">
    </form>
  </div>

</section>

<!-- register admin section ends -->
















<!-- custom js file link  -->
<script src="../js/admin_script.js"></script>

</body>
</html>