<?php

include './connect.php';

session_start();
if(isset($_POST['submit'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);

   $select_dboy = $conn->prepare("SELECT * FROM `dboy` WHERE name = ? AND password = ?");
   $select_dboy->execute([$name, $pass]);
   
   if($select_dboy->rowCount() > 0){
      $fetch_dboy_id = $select_dboy->fetch(PDO::FETCH_ASSOC);
      $_SESSION['dboy_id'] = $fetch_dboy_id['id'];
      header('location:dashboard.php');
   }else{
      $message[] = 'incorrect username or password!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="./css/admin_style.css">

</head>
<body>

<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>

<!-- dboy login form section starts  -->
<style>

h3 {
  text-align: center;
  margin-bottom: 20px;
}


label {
  font-weight: bold;
  display: block;
  margin-bottom: 5px;
  font-size: 15px;
}

.required::after {
  content: '*';
  color: red;
  margin-left: 5px;
}
</style>
<section class="form-container">

   <form action="" method="POST">
      <h3>login now</h3>
      <p>default username = <span>dboy</span> & password = <span>123</span></p>
      <label for="username" align="Left">Enter Username:<span class="required"></span></label>
  <input type="text" id="username" name="name" maxlength="20" required placeholder="Enter your username" class="box" oninput="this.value = this.value.replace(/\s/g, '')">

  <label for="password"align="Left">Enter Password:<span class="required"></span></label>
  <input type="password" id="password" name="pass" maxlength="20" required placeholder="Enter your password" class="box" oninput="this.value = this.value.replace(/\s/g, '')">

  <input type="submit" value="Login Now" name="submit" class="btn">

   </form>

</section>










</body>
</html>