// JavaScript code
const userBtn = document.getElementById('user-btn');
const userOptions = document.getElementById('user-options');

userBtn.addEventListener('click', () => {
  userOptions.classList.toggle('show');
});
